Teaching building OBJ summary package
Generated from campus OBJ files in shandong_teaching_campus_overview_package/models/per_campus_obj.
Target IDs come from Desktop/7-25 SCI-8 numerical data.xlsx, preserving the exact building ID set used by the current simulation dataset.

Folders:
  per_teaching_building_obj_flat: one OBJ per teaching building, named by building_id.
  by_city_obj: one merged OBJ per city.
  combined: one merged OBJ for all 3356 teaching buildings.
  manifest: CSV/XLSX manifest with paths and metadata.

Note: individual building objects are extracted from the already-merged campus OBJ objects such as SD0001_T001_1hao, so merged S/C/E-shaped teaching buildings remain single teaching-building models.
