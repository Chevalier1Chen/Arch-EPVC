# -*- coding: utf-8 -*-
from __future__ import annotations

from pathlib import Path

import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


ROOT = Path(r"C:\Users\DELL\Desktop\SCI8\modeling_6_19")
DATA = ROOT / "data"
OUT = ROOT / "outputs_reduced_variables"
XLSX = OUT / "精简自变量建模数据集与预测结果_不含间距.xlsx"


def read_csv(path):
    return pd.read_csv(path, encoding="utf-8-sig")


def style(ws):
    header_fill = PatternFill("solid", fgColor="1F4E79")
    header_font = Font(color="FFFFFF", bold=True)
    thin = Side(style="thin", color="D9E2F3")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    ws.freeze_panes = "A2"
    for c in ws[1]:
        c.fill = header_fill
        c.font = header_font
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 2000), max_col=min(ws.max_column, 60)):
        for c in row:
            c.border = border
            c.alignment = Alignment(vertical="center", wrap_text=False)
    for col in range(1, ws.max_column + 1):
        letter = get_column_letter(col)
        max_len = 10
        for c in ws[letter][: min(ws.max_row, 200)]:
            max_len = max(max_len, min(len("" if c.value is None else str(c.value)), 44))
        ws.column_dimensions[letter].width = min(max(max_len + 2, 10), 46)


def main():
    metrics = read_csv(OUT / "reduced_model_metrics.csv")
    compare = read_csv(OUT / "reduced_vs_previous_metrics.csv")
    best = metrics.sort_values("R2", ascending=False).groupby("target").head(1).sort_values("target")
    summary = pd.DataFrame(
        [
            ["本轮数据集", "只保留用户指定自变量；已删除教学楼间距；不使用城市、置信度、PV先验、3D体素等额外变量"],
            ["样本量", "3354 栋教学楼；沿用上一轮按校区分组训练/验证/测试划分"],
            ["自变量", "建筑面积、占地面积、屋顶面积、高度、层数、层高、长、宽、朝向、围合方式、体形系数、屋顶/外墙/地面/外窗传热系数"],
            ["最佳EUI", f"{best[best['target']=='EUI']['model'].iloc[0]}：R²={best[best['target']=='EUI']['R2'].iloc[0]:.3f}，RMSE={best[best['target']=='EUI']['RMSE'].iloc[0]:.3f}"],
            ["最佳EPV", f"{best[best['target']=='EPV']['model'].iloc[0]}：R²={best[best['target']=='EPV']['R2'].iloc[0]:.3f}，RMSE={best[best['target']=='EPV']['RMSE'].iloc[0]:.1f}"],
            ["最佳CEI", f"{best[best['target']=='CEI']['model'].iloc[0]}：R²={best[best['target']=='CEI']['R2'].iloc[0]:.3f}，RMSE={best[best['target']=='CEI']['RMSE'].iloc[0]:.3f}"],
            ["解释", "精简变量对EPV很有效，因为屋顶发电量主要由屋顶面积驱动；EUI/CEI下降，说明能耗碳排仍需要气候、运行环境或三维形态信息。"],
        ],
        columns=["项目", "说明"],
    )
    with pd.ExcelWriter(XLSX, engine="openpyxl") as writer:
        summary.to_excel(writer, sheet_name="Summary", index=False)
        read_csv(DATA / "modeling_dataset_reduced_variables.csv").to_excel(writer, sheet_name="Reduced_Modeling_Data", index=False)
        read_csv(DATA / "variable_dictionary_reduced_variables.csv").to_excel(writer, sheet_name="Variable_Dict", index=False)
        metrics.to_excel(writer, sheet_name="Reduced_Metrics", index=False)
        compare.to_excel(writer, sheet_name="Compare_With_Full", index=False)
        read_csv(OUT / "reduced_predictions_test.csv").to_excel(writer, sheet_name="Predictions_Test", index=False)
        read_csv(DATA / "modeling_split.csv").to_excel(writer, sheet_name="Split", index=False)

    wb = load_workbook(XLSX)
    for ws in wb.worksheets:
        style(ws)
    ws = wb["Summary"]
    ws.insert_rows(1)
    ws["A1"] = "精简自变量教学楼性能预测数据集与建模结果（不含间距）"
    ws["A1"].font = Font(color="FFFFFF", bold=True, size=16)
    ws["A1"].fill = PatternFill("solid", fgColor="17365D")
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=2)
    ws.column_dimensions["A"].width = 20
    ws.column_dimensions["B"].width = 118
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row, max_col=2):
        for c in row:
            c.alignment = Alignment(vertical="center", wrap_text=True)
    wb.save(XLSX)

    # A short markdown note for paper writing.
    lines = [
        "# 精简自变量模型结果（不含教学楼间距）",
        "",
        "本轮仅保留：教学楼建筑面积、教学楼占地面积、屋顶面积、教学楼高度、层数、层高、教学楼长、宽、朝向、围合方式、体形系数，以及建设年代对应的屋顶、外墙、地面和外窗传热系数。",
        "",
        "测试集最佳结果：",
    ]
    for _, r in best.iterrows():
        lines.append(f"- {r['target']}：{r['model']}，R²={r['R2']:.3f}，RMSE={r['RMSE']:.3f}，MAE={r['MAE']:.3f}，MAPE={r['MAPE_pct']:.2f}%。")
    lines += [
        "",
        "解释：精简变量对EPV预测效果最好，因为当前EPV为屋顶总发电量，主要由屋顶面积驱动；EUI和CEI相比完整多模态模型明显下降，说明如果论文主打能耗/碳排预测，仍建议保留气候/城市或三维形态信息。",
    ]
    (OUT / "reduced_variables_results_summary.md").write_text("\n".join(lines), encoding="utf-8")
    print(XLSX)


if __name__ == "__main__":
    main()
