# -*- coding: utf-8 -*-
from __future__ import annotations

from pathlib import Path

import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

ROOT = Path(r"C:\Users\DELL\Desktop\SCI8\modeling_6_19")
DATA = ROOT / "data"
OUT = ROOT / "outputs_reduced_variables"
FIG = ROOT / "figures_reduced_variables"
XLSX = OUT / "自变量优化实验与推荐方案.xlsx"


def read_csv(path):
    return pd.read_csv(path, encoding="utf-8-sig")


def style(ws):
    header_fill = PatternFill("solid", fgColor="1F4E79")
    header_font = Font(color="FFFFFF", bold=True)
    thin = Side(style="thin", color="D9E2F3")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    ws.freeze_panes = "A2"
    for c in ws[1]:
        c.fill = header_fill
        c.font = header_font
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 2000), max_col=min(ws.max_column, 80)):
        for c in row:
            c.border = border
            c.alignment = Alignment(vertical="center", wrap_text=False)
    for col in range(1, ws.max_column + 1):
        letter = get_column_letter(col)
        max_len = 10
        for c in ws[letter][: min(ws.max_row, 200)]:
            max_len = max(max_len, min(len("" if c.value is None else str(c.value)), 45))
        ws.column_dimensions[letter].width = min(max(max_len + 2, 10), 48)


def main():
    opt = read_csv(OUT / "optimized_variable_experiments_metrics.csv")
    best = read_csv(OUT / "optimized_final_best_metrics.csv")
    red = read_csv(OUT / "reduced_model_metrics.csv")
    full = read_csv(ROOT / "outputs" / "model_metrics.csv")
    full = full[(full["split"] == "test") & (full["model"] == "LateFusion_Stacked")].copy()

    baseline = red.sort_values("R2", ascending=False).groupby("target").head(1).set_index("target")
    best_idx = best.set_index("target")
    improvements = []
    for target in ["EUI", "EPV", "CEI"]:
        if target in baseline.index and target in best_idx.index:
            improvements.append(
                {
                    "target": target,
                    "baseline_model": baseline.loc[target, "model"],
                    "optimized_model": best_idx.loc[target, "model"],
                    "optimized_variant": best_idx.loc[target, "variant"],
                    "baseline_R2": baseline.loc[target, "R2"],
                    "optimized_R2": best_idx.loc[target, "R2"],
                    "R2_gain": best_idx.loc[target, "R2"] - baseline.loc[target, "R2"],
                    "baseline_RMSE": baseline.loc[target, "RMSE"],
                    "optimized_RMSE": best_idx.loc[target, "RMSE"],
                    "RMSE_reduction_pct": (baseline.loc[target, "RMSE"] - best_idx.loc[target, "RMSE"]) / baseline.loc[target, "RMSE"] * 100,
                }
            )
    imp = pd.DataFrame(improvements)

    recommended_features = pd.DataFrame(
        [
            ["原始几何", "建筑面积、占地面积、屋顶面积、高度、层数、层高、长度、宽度、体形系数", "保留"],
            ["围合方式", "行列式、L/C/E/S/H/回形等", "保留，但只作为一个分类变量"],
            ["朝向", "由原始角度改为 sin/cos", "推荐，解决角度变量非线性和正负方向问题"],
            ["建设年份", "construction_year_numeric", "必须加入，EUI相关性强，且能保留老旧程度信息"],
            ["传热系数", "屋顶、外墙、地面、外窗U值", "保留；缺失值按老建筑保守值填补，避免中位数抹平"],
            ["外窗太阳得热系数", "window_shgc", "推荐加入，影响制冷/采暖与太阳得热"],
            ["经纬度", "lat/lon", "推荐加入，作为连续气候代理；比城市one-hot更干净"],
            ["尺度变换", "log(面积/屋顶/长宽)、长宽比、屋顶面积/建筑面积", "推荐作为派生连续变量，不增加新的外部信息"],
            ["城市one-hot", "16个城市离散变量", "不推荐作为主方案；实验显示提升不明显，经纬度基本够用"],
        ],
        columns=["变量组", "具体字段", "建议"],
    )

    summary = pd.DataFrame(
        [
            ["为什么原精简版下降", "删掉城市/气候信息后，EUI的区域差异无法解释；建设年份没有作为连续变量进入；传热系数约26.9%缺失并被中位数填补，老建筑差异被抹平；朝向和尺度变量未做适当编码。"],
            ["推荐主方案", "V4_engineered_continuous：不加城市one-hot，加入建设年份、SHGC、经纬度、U值物理填补、朝向sin/cos、面积log和比例项。"],
            ["EUI最佳", "V4 + HistGBR：R²=0.865，RMSE=3.701。"],
            ["EPV最佳", "Reduced_MLP：R²=0.829，RMSE=52646.193。EPV当前是屋顶总发电量，主要由屋顶面积解释。"],
            ["CEI最佳", "V3 + HistGBR：R²=0.779，RMSE=2.620。"],
            ["创新点判断", "现有创新点已够：大规模山东教学楼三维数据集、GH批量模拟、OBJ体素/多模态预测、屋顶PV与CEI联合预测。建议再强化变量消融、气候连续变量、外部验证口径说明和可解释性分析。"],
        ],
        columns=["项目", "说明"],
    )

    with pd.ExcelWriter(XLSX, engine="openpyxl") as writer:
        summary.to_excel(writer, sheet_name="Summary", index=False)
        recommended_features.to_excel(writer, sheet_name="Recommended_Features", index=False)
        best.to_excel(writer, sheet_name="Final_Best", index=False)
        imp.to_excel(writer, sheet_name="Improvement", index=False)
        opt.to_excel(writer, sheet_name="All_Optimized_Experiments", index=False)
        red.to_excel(writer, sheet_name="Previous_Reduced", index=False)
        full.to_excel(writer, sheet_name="Previous_Full_Multimodal", index=False)
        read_csv(DATA / "modeling_dataset_reduced_variables.csv").to_excel(writer, sheet_name="Reduced_Data", index=False)

    wb = load_workbook(XLSX)
    for ws in wb.worksheets:
        style(ws)
    ws = wb["Summary"]
    ws.insert_rows(1)
    ws["A1"] = "自变量优化实验与推荐方案"
    ws["A1"].font = Font(color="FFFFFF", bold=True, size=16)
    ws["A1"].fill = PatternFill("solid", fgColor="17365D")
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=2)
    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["B"].width = 120
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row, max_col=2):
        for c in row:
            c.alignment = Alignment(vertical="center", wrap_text=True)
    wb.save(XLSX)

    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        plot_df = pd.concat(
            [
                best.assign(series="Optimized best"),
                red.sort_values("R2", ascending=False).groupby("target").head(1).assign(series="Original reduced best"),
                full[["model", "target", "R2", "RMSE", "MAE", "MAPE_pct", "n"]].assign(variant="Previous_full_multimodal", series="Previous full multimodal"),
            ],
            ignore_index=True,
            sort=False,
        )
        pivot = plot_df.pivot_table(index="series", columns="target", values="R2")
        ax = pivot[["EUI", "EPV", "CEI"]].plot(kind="bar", figsize=(9.5, 4.6), color=["#2F6EA5", "#D9912B", "#7356A5"])
        ax.set_ylabel("R² on grouped test set")
        ax.grid(axis="y", ls="--", alpha=0.25)
        ax.legend(frameon=False, ncol=3)
        plt.xticks(rotation=15, ha="right")
        plt.tight_layout()
        plt.savefig(FIG / "optimized_vs_reduced_full_r2.png", dpi=260)
        plt.close()
    except Exception as exc:
        print("plot skipped", exc)

    md = [
        "# 自变量优化结论",
        "",
        "原精简变量模型下降的主要原因不是模型坏了，而是变量表达损失了关键信息：",
        "- 城市/气候信息被完全删除，而EUI在不同城市之间均值差异很大。",
        "- 建设年份没有作为连续变量进入模型；只靠传热系数不足以表示年久失修和年代差异。",
        "- 传热系数约26.9%缺失，若用全局中位数填补，会抹平老建筑差异。",
        "- 朝向作为角度变量直接输入不理想，改成sin/cos更稳。",
        "",
        "推荐自变量优化：保留原几何变量和围合方式，加入建设年份、外窗太阳得热系数、经纬度气候代理，对U值缺失做物理填补，并加入朝向sin/cos、面积log、长宽比、屋顶面积/建筑面积等派生连续变量。",
        "",
        "最终最佳测试集结果：",
    ]
    for _, r in best.sort_values("target").iterrows():
        md.append(f"- {r['target']}：{r['variant']} + {r['model']}，R²={r['R2']:.3f}，RMSE={r['RMSE']:.3f}，MAE={r['MAE']:.3f}，MAPE={r['MAPE_pct']:.2f}%。")
    md += [
        "",
        "论文创新点建议：当前主线已经够，不必上扩散模型。建议把精力放在变量消融、连续气候代理、模型可解释性（SHAP/Permutation importance）和外部验证口径说明上。",
    ]
    (OUT / "optimized_variables_recommendation.md").write_text("\n".join(md), encoding="utf-8")
    print(XLSX)


if __name__ == "__main__":
    main()
