# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import random
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset


SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

ROOT = Path(r"C:\Users\DELL\Desktop\SCI8\modeling_6_19")
DATA = ROOT / "data"
OUT = ROOT / "outputs_reduced_variables"
FIG = ROOT / "figures_reduced_variables"
MODEL = ROOT / "models_reduced_variables"
for d in (OUT, FIG, MODEL):
    d.mkdir(parents=True, exist_ok=True)

TARGETS = ["EUI_kWh_m2", "EPV_roof_kWh", "CEI_with_PV_kgCO2_m2"]
LABELS = ["EUI", "EPV", "CEI"]


class MLP(nn.Module):
    def __init__(self, in_dim, out_dim=3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(0.08),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(0.05),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, out_dim),
        )

    def forward(self, x):
        return self.net(x)


class FeatureTransformer(nn.Module):
    def __init__(self, in_dim, out_dim=3, d_model=40, nhead=4):
        super().__init__()
        self.value_proj = nn.Linear(1, d_model)
        self.feature_embed = nn.Parameter(torch.randn(in_dim, d_model) * 0.02)
        layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=nhead, dim_feedforward=128, dropout=0.08, batch_first=True, activation="gelu")
        self.encoder = nn.TransformerEncoder(layer, num_layers=2)
        self.head = nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, 64), nn.GELU(), nn.Linear(64, out_dim))

    def forward(self, x):
        z = self.value_proj(x.unsqueeze(-1)) + self.feature_embed.unsqueeze(0)
        z = self.encoder(z).mean(dim=1)
        return self.head(z)


def metrics_rows(y_true, y_pred, model, split):
    rows = []
    for i, label in enumerate(LABELS):
        yt = y_true[:, i]
        yp = y_pred[:, i]
        rows.append(
            {
                "model": model,
                "split": split,
                "target": label,
                "R2": r2_score(yt, yp),
                "RMSE": mean_squared_error(yt, yp) ** 0.5,
                "MAE": mean_absolute_error(yt, yp),
                "MAPE_pct": np.mean(np.abs((yt - yp) / np.maximum(np.abs(yt), 1e-6))) * 100,
                "n": len(yt),
            }
        )
    return rows


def train_torch_model(name, model, x_train, y_train, x_val, y_val, x_test, y_test, target_scaler, max_epochs=120, patience=18, lr=1e-3):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    train_loader = DataLoader(TensorDataset(torch.tensor(x_train, dtype=torch.float32), torch.tensor(y_train, dtype=torch.float32)), batch_size=128, shuffle=True)
    val_x = torch.tensor(x_val, dtype=torch.float32).to(device)
    val_y = torch.tensor(y_val, dtype=torch.float32).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    loss_fn = nn.MSELoss()
    best, best_state, wait = float("inf"), None, 0
    hist = []
    for epoch in range(1, max_epochs + 1):
        model.train()
        train_loss, n = 0.0, 0
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad(set_to_none=True)
            loss = loss_fn(model(xb), yb)
            loss.backward()
            opt.step()
            train_loss += float(loss.item()) * len(yb)
            n += len(yb)
        train_loss /= max(n, 1)
        model.eval()
        with torch.no_grad():
            val_loss = float(loss_fn(model(val_x), val_y).item())
        hist.append({"model": name, "epoch": epoch, "train_loss": train_loss, "val_loss": val_loss})
        if epoch % 10 == 0 or epoch == 1:
            print(f"{name:22s} epoch {epoch:03d} train={train_loss:.4f} val={val_loss:.4f}")
        if val_loss < best - 1e-5:
            best = val_loss
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            wait = 0
        else:
            wait += 1
            if wait >= patience:
                print(f"{name:22s} early stop at {epoch}, best={best:.4f}")
                break
    if best_state:
        model.load_state_dict(best_state)
    torch.save(model.state_dict(), MODEL / f"{name}.pt")
    model.to(device).eval()
    with torch.no_grad():
        pred_scaled = model(torch.tensor(x_test, dtype=torch.float32).to(device)).cpu().numpy()
    pred = np.expm1(target_scaler.inverse_transform(pred_scaled))
    return pred, pd.DataFrame(hist)


def main():
    cfg = json.loads((DATA / "reduced_variables_config.json").read_text(encoding="utf-8"))
    df = pd.read_csv(DATA / "modeling_dataset_reduced_variables.csv", encoding="utf-8-sig")
    split = pd.read_csv(DATA / "modeling_split.csv", encoding="utf-8-sig")
    df = df.merge(split[["building_uid", "split"]], on="building_uid", how="left")

    feature_cols = cfg["feature_cols_cn"]
    cat_cols = cfg["categorical_feature_cols_cn"]
    num_cols = [c for c in feature_cols if c not in cat_cols]
    Xn = df[num_cols].apply(pd.to_numeric, errors="coerce")
    Xc = pd.get_dummies(df[cat_cols].fillna("未知").astype(str), prefix=cat_cols)
    Xraw = pd.concat([Xn, Xc], axis=1)
    y_raw = df[TARGETS].to_numpy(float)

    train = df["split"].eq("train").to_numpy()
    val = df["split"].eq("val").to_numpy()
    test = df["split"].eq("test").to_numpy()
    trainval = train | val

    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()
    X_train_imp = imputer.fit_transform(Xraw.loc[train])
    scaler.fit(X_train_imp)
    X = scaler.transform(imputer.transform(Xraw)).astype(np.float32)

    target_scaler = StandardScaler()
    ylog = np.log1p(y_raw)
    target_scaler.fit(ylog[train])
    y_scaled = target_scaler.transform(ylog).astype(np.float32)

    metrics = []
    histories = []
    pred_rows = []

    # Classical robust baselines, still using only the reduced variable set.
    for name, reg in [
        ("Reduced_ExtraTrees", ExtraTreesRegressor(n_estimators=700, min_samples_leaf=2, max_features=0.85, random_state=SEED, n_jobs=-1)),
        ("Reduced_RandomForest", RandomForestRegressor(n_estimators=500, min_samples_leaf=2, max_features=0.85, random_state=SEED + 1, n_jobs=-1)),
    ]:
        pipe = make_pipeline(SimpleImputer(strategy="median"), reg)
        pipe.fit(Xraw.loc[trainval], np.log1p(y_raw[trainval]))
        pred = np.expm1(pipe.predict(Xraw.loc[test]))
        metrics.extend(metrics_rows(y_raw[test], pred, name, "test"))
        for i, uid in enumerate(df.loc[test, "building_uid"]):
            pred_rows.append({"model": name, "building_uid": uid, **{f"{lab}_true": y_raw[test][i, j] for j, lab in enumerate(LABELS)}, **{f"{lab}_pred": pred[i, j] for j, lab in enumerate(LABELS)}})

    for name, model, epochs, patience, lr in [
        ("Reduced_MLP", MLP(X.shape[1]), 120, 18, 1e-3),
        ("Reduced_Transformer", FeatureTransformer(X.shape[1]), 100, 16, 8e-4),
    ]:
        pred, hist = train_torch_model(
            name,
            model,
            X[train],
            y_scaled[train],
            X[val],
            y_scaled[val],
            X[test],
            y_raw[test],
            target_scaler,
            max_epochs=epochs,
            patience=patience,
            lr=lr,
        )
        histories.append(hist)
        metrics.extend(metrics_rows(y_raw[test], pred, name, "test"))
        for i, uid in enumerate(df.loc[test, "building_uid"]):
            pred_rows.append({"model": name, "building_uid": uid, **{f"{lab}_true": y_raw[test][i, j] for j, lab in enumerate(LABELS)}, **{f"{lab}_pred": pred[i, j] for j, lab in enumerate(LABELS)}})

    metrics_df = pd.DataFrame(metrics)
    preds_df = pd.DataFrame(pred_rows)
    metrics_df.to_csv(OUT / "reduced_model_metrics.csv", index=False, encoding="utf-8-sig")
    preds_df.to_csv(OUT / "reduced_predictions_test.csv", index=False, encoding="utf-8-sig")
    if histories:
        pd.concat(histories, ignore_index=True).to_csv(OUT / "reduced_training_history.csv", index=False, encoding="utf-8-sig")

    # Compare with previous full-variable late-fusion result.
    full = pd.read_csv(ROOT / "outputs" / "model_metrics.csv", encoding="utf-8-sig")
    full_best = full[(full["split"] == "test") & (full["model"] == "LateFusion_Stacked")].copy()
    full_best["model"] = "Previous_LateFusion_full"
    compare = pd.concat([metrics_df, full_best[["model", "split", "target", "R2", "RMSE", "MAE", "MAPE_pct", "n"]]], ignore_index=True)
    compare.to_csv(OUT / "reduced_vs_previous_metrics.csv", index=False, encoding="utf-8-sig")

    # Simple final figure.
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        pivot = compare.pivot_table(index="model", columns="target", values="R2")
        ax = pivot[["EUI", "EPV", "CEI"]].plot(kind="bar", figsize=(10.5, 4.8), color=["#2F6EA5", "#D9912B", "#7356A5"])
        ax.set_ylabel("R² on grouped test set")
        ax.grid(axis="y", ls="--", alpha=0.25)
        ax.legend(frameon=False, ncol=3)
        plt.xticks(rotation=24, ha="right")
        plt.tight_layout()
        plt.savefig(FIG / "reduced_variables_r2_comparison.png", dpi=260)
        plt.close()
    except Exception as exc:
        print("plot skipped", exc)

    summary = {
        "n_rows": int(len(df)),
        "n_train": int(train.sum()),
        "n_val": int(val.sum()),
        "n_test": int(test.sum()),
        "features": feature_cols,
        "encoded_feature_count": int(X.shape[1]),
        "metrics": metrics_df.to_dict(orient="records"),
    }
    (OUT / "reduced_modeling_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(metrics_df.sort_values(["target", "R2"], ascending=[True, False]).to_string(index=False))
    print("saved to", OUT)


if __name__ == "__main__":
    main()
