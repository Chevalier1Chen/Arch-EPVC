# -*- coding: utf-8 -*-
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(r"C:\Users\DELL\Desktop\SCI8\modeling_6_19")
DATA = ROOT / "data"
OUT = ROOT / "outputs_reduced_variables"
OUT.mkdir(parents=True, exist_ok=True)


def main():
    df = pd.read_csv(DATA / "modeling_dataset_clean.csv", encoding="utf-8-sig")
    print("loading clean dataset", df.shape)

    metadata_cols = [
        "building_uid",
        "sample_uid",
        "city",
        "school_name",
        "obj_path",
        "construction_year_user",
        "construction_year_numeric",
    ]
    feature_cols = [
        "building_area_m2",
        "footprint_area_m2",
        "roof_area_m2",
        "height_m",
        "estimated_floor_count",
        "story_height_m",
        "length_m",
        "width_m",
        "orientation_deg",
        "A8_enclosure_type",
        "shape_factor",
        "roof_u_w_m2k",
        "wall_u_w_m2k",
        "ground_u_w_m2k",
        "window_u_w_m2k",
    ]
    target_cols = [
        "target_eui_kwh_m2",
        "target_epv_roof_kwh",
        "target_cei_with_pv_kgco2_m2",
    ]
    out = df[metadata_cols + feature_cols + target_cols].copy()
    out = out.rename(
        columns={
            "building_area_m2": "教学楼建筑面积_m2",
            "footprint_area_m2": "教学楼占地面积_m2",
            "roof_area_m2": "屋顶面积_m2",
            "height_m": "教学楼高度_m",
            "estimated_floor_count": "层数",
            "story_height_m": "层高_m",
            "length_m": "教学楼长度_m",
            "width_m": "教学楼宽度_m",
            "orientation_deg": "朝向_deg",
            "A8_enclosure_type": "围合方式",
            "shape_factor": "体形系数",
            "roof_u_w_m2k": "屋顶传热系数_W_m2K",
            "wall_u_w_m2k": "外墙传热系数_W_m2K",
            "ground_u_w_m2k": "地面传热系数_W_m2K",
            "window_u_w_m2k": "外窗传热系数_W_m2K",
            "target_eui_kwh_m2": "EUI_kWh_m2",
            "target_epv_roof_kwh": "EPV_roof_kWh",
            "target_cei_with_pv_kgco2_m2": "CEI_with_PV_kgCO2_m2",
        }
    )
    out.to_csv(DATA / "modeling_dataset_reduced_variables.csv", index=False, encoding="utf-8-sig")

    dict_rows = [
        ("教学楼建筑面积_m2", "教学楼建筑面积", "m2", "占地面积×层数/高度估算"),
        ("教学楼占地面积_m2", "教学楼底面占地面积", "m2", "OBJ/GIS轮廓计算"),
        ("屋顶面积_m2", "教学楼屋顶面积", "m2", "屋顶投影面积"),
        ("教学楼高度_m", "教学楼建筑高度", "m", "3D-GloBFP/OBJ高度"),
        ("层数", "教学楼层数", "层", "高度与层高推算或原始属性"),
        ("层高_m", "建筑层高", "m", "GH输入表"),
        ("教学楼长度_m", "教学楼长向尺寸", "m", "平面外包尺寸"),
        ("教学楼宽度_m", "教学楼短向尺寸", "m", "平面外包尺寸"),
        ("朝向_deg", "朝向，正南为0，南偏东为正，南偏西为负", "degree", "平面方向计算"),
        ("围合方式", "教学楼平面围合方式", "分类", "行列式、L/C/E/S/H/回形等"),
        ("体形系数", "体形系数", "-", "外表面积/体积近似"),
        ("屋顶传热系数_W_m2K", "屋顶传热系数", "W/m2K", "按建设年代与体形系数映射"),
        ("外墙传热系数_W_m2K", "外墙传热系数", "W/m2K", "按建设年代与体形系数映射"),
        ("地面传热系数_W_m2K", "地面传热系数", "W/m2K", "按建设年代与体形系数映射"),
        ("外窗传热系数_W_m2K", "外窗传热系数", "W/m2K", "按建设年代与体形系数映射"),
        ("EUI_kWh_m2", "年单位面积能耗", "kWh/m2", "6-19模拟结果"),
        ("EPV_roof_kWh", "年屋顶光伏发电量", "kWh", "6-19模拟结果；当前不含南立面"),
        ("CEI_with_PV_kgCO2_m2", "考虑光伏抵扣后的年碳排放强度", "kgCO2/m2", "6-19模拟结果"),
    ]
    pd.DataFrame(dict_rows, columns=["field", "meaning", "unit", "source_or_calculation"]).to_csv(
        DATA / "variable_dictionary_reduced_variables.csv", index=False, encoding="utf-8-sig"
    )

    config = {
        "n_rows": int(len(out)),
        "feature_cols_cn": [
            "教学楼建筑面积_m2",
            "教学楼占地面积_m2",
            "屋顶面积_m2",
            "教学楼高度_m",
            "层数",
            "层高_m",
            "教学楼长度_m",
            "教学楼宽度_m",
            "朝向_deg",
            "围合方式",
            "体形系数",
            "屋顶传热系数_W_m2K",
            "外墙传热系数_W_m2K",
            "地面传热系数_W_m2K",
            "外窗传热系数_W_m2K",
        ],
        "target_cols_cn": ["EUI_kWh_m2", "EPV_roof_kWh", "CEI_with_PV_kgCO2_m2"],
        "categorical_feature_cols_cn": ["围合方式"],
        "spacing_note": "按用户要求，教学楼间距未纳入本轮自变量。",
        "excluded_from_features": ["city", "confidence", "envelope_standard_bucket", "shape_factor_bin", "pv_city_yield_prior", "window_shgc"],
    }
    (DATA / "reduced_variables_config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(config, ensure_ascii=False, indent=2))
    print(out.head(3).to_string(index=False))


if __name__ == "__main__":
    main()
