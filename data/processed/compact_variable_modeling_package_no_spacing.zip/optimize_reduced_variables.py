# -*- coding: utf-8 -*-
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path(r"C:\Users\DELL\Desktop\SCI8\modeling_6_19")
DATA = ROOT / "data"
OUT = ROOT / "outputs_reduced_variables"
OUT.mkdir(exist_ok=True)

TARGETS = ["EUI_kWh_m2", "EPV_roof_kWh", "CEI_with_PV_kgCO2_m2"]
LABELS = ["EUI", "EPV", "CEI"]


def metrics(yt, yp, model, variant, target):
    return {
        "variant": variant,
        "model": model,
        "target": target,
        "R2": r2_score(yt, yp),
        "RMSE": mean_squared_error(yt, yp) ** 0.5,
        "MAE": mean_absolute_error(yt, yp),
        "MAPE_pct": np.mean(np.abs((yt - yp) / np.maximum(np.abs(yt), 1e-6))) * 100,
        "n": len(yt),
    }


def add_engineered(df, base_full):
    out = df.copy()
    # Continuous location proxy for climate. It is less discrete than city one-hot.
    schools = pd.read_csv(
        r"C:\Users\DELL\Desktop\SCI8\shandong_teaching_campus_overview_package\data\schools_teaching_campus.csv",
        encoding="utf-8-sig",
    )[["sample_uid", "lat", "lon"]]
    out = out.merge(schools, on="sample_uid", how="left")
    out["建设年份_numeric"] = out["construction_year_numeric"]
    out["外窗太阳得热系数"] = base_full["window_shgc"].to_numpy()

    # Fill missing U-values in a physically conservative way: keep the standard
    # bucket signal instead of replacing old buildings by global medians.
    u_cols = ["屋顶传热系数_W_m2K", "外墙传热系数_W_m2K", "地面传热系数_W_m2K", "外窗传热系数_W_m2K"]
    for c in u_cols:
        out[c + "_filled"] = out[c]
    old_mask = out["建设年份_numeric"] < 2006
    fill_values = {
        "屋顶传热系数_W_m2K_filled": 0.91,
        "外墙传热系数_W_m2K_filled": 1.28,
        "地面传热系数_W_m2K_filled": 2.0,
        "外窗传热系数_W_m2K_filled": 6.4,
    }
    for c, v in fill_values.items():
        out.loc[old_mask & out[c].isna(), c] = v

    rad = np.deg2rad(out["朝向_deg"].astype(float))
    out["朝向_sin"] = np.sin(rad)
    out["朝向_cos"] = np.cos(rad)
    for c in ["教学楼建筑面积_m2", "教学楼占地面积_m2", "屋顶面积_m2", "教学楼长度_m", "教学楼宽度_m"]:
        out["log_" + c] = np.log1p(pd.to_numeric(out[c], errors="coerce"))
    out["长宽比"] = out["教学楼长度_m"] / out["教学楼宽度_m"].replace(0, np.nan)
    out["屋顶面积_建筑面积比"] = out["屋顶面积_m2"] / out["教学楼建筑面积_m2"].replace(0, np.nan)
    return out


def prepare_xy(df, feature_cols, cat_cols):
    num_cols = [c for c in feature_cols if c not in cat_cols]
    Xn = df[num_cols].apply(pd.to_numeric, errors="coerce")
    Xc = pd.get_dummies(df[cat_cols].fillna("未知").astype(str), prefix=cat_cols)
    return pd.concat([Xn, Xc], axis=1)


def run_variant(df, variant, feature_cols, cat_cols):
    split = df["split"]
    train = split.eq("train").to_numpy()
    val = split.eq("val").to_numpy()
    test = split.eq("test").to_numpy()
    trainval = train | val
    X = prepare_xy(df, feature_cols, cat_cols)
    y = df[TARGETS].to_numpy(float)

    rows = []
    preds = []
    # Independent target models. This avoids EPV dominating/competing with EUI.
    for target_idx, label in enumerate(LABELS):
        yt_train = np.log1p(y[trainval, target_idx])
        yt_test = y[test, target_idx]
        models = {
            "ExtraTrees_single": ExtraTreesRegressor(n_estimators=800, min_samples_leaf=2, max_features=0.85, random_state=42 + target_idx, n_jobs=-1),
            "RandomForest_single": RandomForestRegressor(n_estimators=600, min_samples_leaf=2, max_features=0.85, random_state=72 + target_idx, n_jobs=-1),
            "HistGBR_single": HistGradientBoostingRegressor(max_iter=450, learning_rate=0.045, l2_regularization=0.02, max_leaf_nodes=31, random_state=100 + target_idx),
        }
        for model_name, reg in models.items():
            if model_name == "HistGBR_single":
                pipe = make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), reg)
            else:
                pipe = make_pipeline(SimpleImputer(strategy="median"), reg)
            pipe.fit(X.loc[trainval], yt_train)
            yp = np.expm1(pipe.predict(X.loc[test]))
            rows.append(metrics(yt_test, yp, model_name, variant, label))
            for uid, t, p in zip(df.loc[test, "building_uid"], yt_test, yp):
                preds.append({"variant": variant, "model": model_name, "target": label, "building_uid": uid, "true": t, "pred": p})
    return pd.DataFrame(rows), pd.DataFrame(preds)


def main():
    cfg = json.loads((DATA / "reduced_variables_config.json").read_text(encoding="utf-8"))
    red = pd.read_csv(DATA / "modeling_dataset_reduced_variables.csv", encoding="utf-8-sig")
    full = pd.read_csv(DATA / "modeling_dataset_clean.csv", encoding="utf-8-sig")
    split = pd.read_csv(DATA / "modeling_split.csv", encoding="utf-8-sig")
    red = red.merge(split[["building_uid", "split"]], on="building_uid", how="left")
    full = full.set_index("building_uid").loc[red["building_uid"]].reset_index()
    df = add_engineered(red, full)

    base_features = cfg["feature_cols_cn"]
    base_cat = ["围合方式"]
    variants = {
        "V0_reduced_original": (base_features, base_cat),
        "V1_add_year": (base_features + ["建设年份_numeric"], base_cat),
        "V2_add_year_shgc": (base_features + ["建设年份_numeric", "外窗太阳得热系数"], base_cat),
        "V3_add_latlon_year_shgc": (base_features + ["建设年份_numeric", "外窗太阳得热系数", "lat", "lon"], base_cat),
        "V4_engineered_continuous": (
            [
                "教学楼建筑面积_m2",
                "教学楼占地面积_m2",
                "屋顶面积_m2",
                "教学楼高度_m",
                "层数",
                "层高_m",
                "教学楼长度_m",
                "教学楼宽度_m",
                "朝向_sin",
                "朝向_cos",
                "体形系数",
                "屋顶传热系数_W_m2K_filled",
                "外墙传热系数_W_m2K_filled",
                "地面传热系数_W_m2K_filled",
                "外窗传热系数_W_m2K_filled",
                "建设年份_numeric",
                "外窗太阳得热系数",
                "lat",
                "lon",
                "log_教学楼建筑面积_m2",
                "log_教学楼占地面积_m2",
                "log_屋顶面积_m2",
                "长宽比",
                "屋顶面积_建筑面积比",
            ],
            base_cat,
        ),
        "V5_engineered_plus_city": (
            [
                "教学楼建筑面积_m2",
                "教学楼占地面积_m2",
                "屋顶面积_m2",
                "教学楼高度_m",
                "层数",
                "层高_m",
                "教学楼长度_m",
                "教学楼宽度_m",
                "朝向_sin",
                "朝向_cos",
                "体形系数",
                "屋顶传热系数_W_m2K_filled",
                "外墙传热系数_W_m2K_filled",
                "地面传热系数_W_m2K_filled",
                "外窗传热系数_W_m2K_filled",
                "建设年份_numeric",
                "外窗太阳得热系数",
                "lat",
                "lon",
                "log_教学楼建筑面积_m2",
                "log_教学楼占地面积_m2",
                "log_屋顶面积_m2",
                "长宽比",
                "屋顶面积_建筑面积比",
                "city",
            ],
            base_cat + ["city"],
        ),
    }

    all_metrics = []
    all_preds = []
    for variant, (features, cats) in variants.items():
        print("running", variant, "features", len(features), "cats", cats)
        m, p = run_variant(df, variant, features, cats)
        all_metrics.append(m)
        all_preds.append(p)
    metrics_df = pd.concat(all_metrics, ignore_index=True)
    preds_df = pd.concat(all_preds, ignore_index=True)
    metrics_df.to_csv(OUT / "optimized_variable_experiments_metrics.csv", index=False, encoding="utf-8-sig")
    preds_df.to_csv(OUT / "optimized_variable_experiments_predictions.csv", index=False, encoding="utf-8-sig")

    best = metrics_df.sort_values("R2", ascending=False).groupby("target").head(5).sort_values(["target", "R2"], ascending=[True, False])
    best.to_csv(OUT / "optimized_variable_best_by_target.csv", index=False, encoding="utf-8-sig")
    print(best.to_string(index=False))
    print("saved", OUT)


if __name__ == "__main__":
    main()
